# Version 1.0.2 -

Release the Kraken!

# Version 1.0.3 -

Now with even more Undercroft, additional rooms that can be filled with your creativity!

# Version 1.0.4 -

Had to move the undercrofts to prevent some issues, I am sorry if you had builds in the previous version, you might be
able to just avoid updating however in updating this fixes a few issues found.

# Version 1.0.5 -

Added pieces to build menu, use them to customize your undercroft!

# Version 1.0.6 -

Fixed Compatability issues.

# Version 1.0.7 -

Fixed Compatability issues with <a href="https://github.com/redseiko/ValheimMods/releases">Comfy Gizmo Rotation Mod</a>

# Version 1.0.8

Sorry I lied, this is the fix for Comfy Gizmo and ValheimRaft Compat.

# Version 1.0.9

Sorry I lied, I wasnt able to fix compatability with ValheimRaft. So instead I fixed the crappy job I did on snap points
for the walls and added a few more deco blocks for you!

# Version 1.1.0

Texture Correction on hallway and forgot snappoint to OU_Stonebeam

# Version 1.1.1

Fixed Scale of pieces to match vanillia scale. added stair piece  (Sorry again about the piece alignment, when updating
walls and doors may have to be reset but this is for the better to match scale).

# Version 1.1.2

* Added piece restrictions - Odins_BuildSkull is now required when building Odins Undercroft build pieces outside of the
  Undercroft.
* This was by request to add simular mechanics to the build pieces.
* The inside of the undercroft allows full placement of the pieces.
* Added Large Stone Pillar.

# Version 1.1.3

Fixed Server Sync, Fixed WearNTear missing children.

- notes about the Odins_Build_Skull, this can be set to restrict crafting of OdinsUndercroft pieces by changing it's
  crafting requirements to something like "SwordCheat". Pieces for Undercroft can then only be crafted inside of the
  undercroft. The Build Skull sort of works like a Stonecutter with area build restrictions by default.

# Version 1.1.4

ModWish Request filled - "Add another size beam to fit the walls".

# Version 1.1.5

ModWish Request filled - "Remove Smoke Effect of Enviroment"

# Version 1.1.7

Fixed roof - it will now act as a roof

# Version 1.1.8

Fixed missing circle projector NRE from placing skull, added a floor piece.

# Version 1.1.9

Added more floor pieces and roof pieces.

# Version 1.1.10

Updated PieceManager and ServerSync

# Version 1.1.11

Fixed patch for mistlands - thanks azumatt

# Version 1.1.12

Updated dependencies

# Version 1.1.13

Update for Valheim 0.216.9

# Version 1.1.14

Fix for connection bug. 