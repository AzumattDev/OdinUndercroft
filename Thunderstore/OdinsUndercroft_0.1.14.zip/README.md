
<p align="center">

NEW BUILD PIECES!  USE [SearsCatalog](https://valheim.thunderstore.io/package/ComfyMods/SearsCatalog/) IF YOU NEED MORE ROOM IN YOUR HAMMER!

</p>


<h2>  About: </h2>

>OdinsUndercroft is a private basement more fitting for a viking lord then some dirty hole in the ground.

<h2>  Features:</h2>

>A buildable "Dungeon/Undercroft" added to the Hammer under your Crafting Tab.

>New 3 teleport locations within Undercroft (2 rooms and 1 hallway) for you to decorate.

>Prevent accidental demolish when building inside.

>Range check to prevent building too close to another Undercroft.

>Heavy performance optimization within Undercroft!



<p align="center">

<img src="https://media.giphy.com/media/9sUTroAUKjVN0Na3Rs/giphy-downsized-large.gif">

</p>

<p align="center">

<img src="https://media.giphy.com/media/1fG6AqbfW47xQyvXZi/giphy-downsized-large.gif">

</p>

<p align="center">

<img src="https://media.giphy.com/media/89salLep5hRIzChqlj/giphy-downsized-large.gif">

</p>

Click the Sign to Buymeacoffee:

<p align="center"><a href="https://www.buymeacoffee.com/Gravebear"><img src="https://i.imgur.com/f0x2wj0.png"></a></p>



<h2>  Install Notes: </h2>

>Mod is required on both server and client for config sync to work.

<h2> Manual Install: </h2>

>>Please download the latest copy of Bepinex per author's instructions.

>>Place the OdinUndercoft Folder inside of the "Bepinex\plugins\" folder.

<p>

<p align="center"><h2>For Questions or Comments find Gravebear in the Odin Plus Team on Discord:</h2></p>

<p align="center"><a href="https://discord.gg/mbkPcvu9ax"><img src="https://i.imgur.com/Ji3u63C.png"></a></p>

<h2>Special Thanks to Haus for help with code, Azumatt, Blaxxun, and of course all of the OdinPlus Team and community!